module.exports = {
    mongoURI: 'mongodb://ecosyn:13579111315@ds247678.mlab.com:47678/apdlca',
    //mongoURI: 'mongodb://localhost/apdlca',
    googleClientID: '534700586866-vn91vc6t7bgqut7k07s0tc3o89dkkge2.apps.googleusercontent.com',
    googleClientSecret: 'XqHaY9tcn-5gypYq6Bu6d1R3'
};